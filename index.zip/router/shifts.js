const express = require("express")
const Shifts = require("../models/shifts");
const Sites = require("../models/sites")
const Customers = require("../models/customers")
const Users = require("../models/auth")
const dayjs = require("dayjs");
const utc = require('dayjs/plugin/utc');
const timezone = require('dayjs/plugin/timezone');
const multer = require("multer");
const cloudinary = require("cloudinary").v2;
const { verifyToken } = require("../middlewares/auth")
const { getRandomId, cleanObjectValues } = require("../config/global");

const storage = multer.memoryStorage()
const upload = multer({ storage })

dayjs.extend(utc);
dayjs.extend(timezone);

const router = express.Router()

router.post("/add", verifyToken, async (req, res) => {
    try {
        const { uid } = req;

        const user = await Users.findOne({ uid })
        if (!user) return res.status(401).json({ message: "Unauthorized access.", isError: true })

        let formData = req.body

        const site = await Sites.findOne({ id: formData.siteId }).select('-createdBy -__v -_id')

        const shift = new Shifts({ ...formData, id: getRandomId(), createdBy: uid, companyId: user.companyId, customerId: site.customerId })
        await shift.save()

        let shiftObject = shift.toObject();
        if (site) { shiftObject.siteId = site.toObject(); }

        const guardId = shiftObject.guardId;

        if (guardId && req.io) {
            req.io.to(guardId).emit('new_shift_added', { shift: shiftObject, message: `Your new shift add at ${shiftObject?.siteId?.name}`, });
        }

        res.status(201).json({ message: "Your shift added has been successfully", isError: false, shift })

    } catch (error) {
        console.error(error)
        res.status(500).json({ message: "Something went wrong while adding the shift", isError: true, error })
    }
})

router.get("/all", verifyToken, async (req, res) => {
    try {

        const { uid } = req;

        const user = await Users.findOne({ uid })
        if (!user) return res.status(401).json({ message: "Unauthorized access.", isError: true })

        const { customerId, model, startDate, endDate } = cleanObjectValues(req.query);

        let start = JSON.parse(startDate);
        let end = JSON.parse(endDate);

        if (model === "Sites") {

            let match = {};
            if (customerId) match.customerId = customerId
            if (user.companyId) match.companyId = user.companyId
            match.status = "active"
            const result = await Sites.aggregate([
                { $match: match },
                { $lookup: { from: "shifts", localField: "id", foreignField: "siteId", as: "shifts" } },
                { $unwind: { path: "$shifts", preserveNullAndEmptyArrays: true } },
                { $lookup: { from: "users", localField: "shifts.guardId", foreignField: "uid", as: "guardInfo" } },
                { $unwind: { path: "$guardInfo", preserveNullAndEmptyArrays: true } },
                {
                    $group: {
                        _id: "$id",
                        name: { $first: "$name" },
                        shifts: {
                            $push: { id: "$shifts.id", guardId: "$shifts.guardId", siteId: "$shifts.siteId", breakTime: "$shifts.breakTime", date: "$shifts.date", employeeName: "$guardInfo.fullName", start: "$shifts.start", end: "$shifts.end", status: "$shifts.status", liveStatus: "$shifts.liveStatus", totalHours: "$shifts.totalHours" }
                        }
                    }
                },
                {
                    $project: {
                        _id: 0, id: "$_id", name: 1,
                        shifts: {
                            $filter: {
                                input: "$shifts", as: "s",
                                cond: {
                                    $and: [
                                        { $ne: ["$$s.id", null] },
                                        start ? { $gte: ["$$s.date", { $dateFromString: { dateString: start } }] } : true,
                                        end ? { $lte: ["$$s.date", { $dateFromString: { dateString: end } }] } : true
                                    ]
                                }
                            }
                        }
                    }
                }
            ]);

            return res.json({ model: "sites", data: result });
        }

        if (model === "Guards") {

            let match = {}
            match.roles = { $in: ["guard"] }
            if (user.companyId) match.companyId = user.companyId
            match.status = "active"

            const result = await Users.aggregate([
                { $match: match },
                { $lookup: { from: "shifts", localField: "uid", foreignField: "guardId", as: "shifts" } },
                { $unwind: { path: "$shifts", preserveNullAndEmptyArrays: true } },
                { $lookup: { from: "sites", localField: "shifts.siteId", foreignField: "id", as: "siteInfo" } },
                { $unwind: { path: "$siteInfo", preserveNullAndEmptyArrays: true } },
                {
                    $group: {
                        _id: "$uid", name: { $first: "$fullName" },
                        shifts: { $push: { id: "$shifts.id", guardId: "$shifts.guardId", siteId: "$shifts.siteId", breakTime: "$shifts.breakTime", date: "$shifts.date", siteName: "$siteInfo.name", start: "$shifts.start", end: "$shifts.end", status: "$shifts.status", liveStatus: "$shifts.liveStatus", totalHours: "$shifts.totalHours" } }
                    }
                },
                {
                    $project: {
                        _id: 0, id: "$_id", name: 1,
                        shifts: {
                            $filter: {
                                input: "$shifts", as: "s",
                                cond: {
                                    $and: [
                                        { $ne: ["$$s.id", null] },
                                        start ? { $gte: ["$$s.date", { $dateFromString: { dateString: start } }] } : true,
                                        end ? { $lte: ["$$s.date", { $dateFromString: { dateString: end } }] } : true
                                    ]
                                }
                            }
                        }
                    }
                }
            ]);

            return res.json({ model: "employees", data: result });
        }

        return res.status(400).json({ message: "Invalid model. Use /site or /guard" });

    } catch (err) {
        console.log(err);
        res.status(500).json({ message: "Server Error", err });
    }
});

router.get("/single-with-id/:id", verifyToken, async (req, res) => {
    try {

        const { uid } = req;
        if (!uid) return res.status(401).json({ message: "Unauthorized access.", isError: true });

        const { id } = req.params;

        const shift = await Shifts.findOne({ id });

        res.status(200).json({ shift });

    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Something went wrong. Internal server error.", isError: true, error });
    }
});

router.get("/my-shifts", verifyToken, async (req, res) => {
    try {
        const { uid } = req;

        const user = await Users.findOne({ uid });

        if (!user) { return res.status(401).json({ message: "Unauthorized access.", isError: true }); }

        let { startDate, endDate } = cleanObjectValues(req.query);

        startDate = JSON.parse(startDate)
        endDate = JSON.parse(endDate)

        const start = dayjs(startDate);
        const end = dayjs(endDate);

        if (!start.isValid() || !end.isValid()) { return res.status(400).json({ message: "Invalid date format.", isError: true }); }

        const startFilter = start.startOf("day").toDate();
        const endFilter = end.endOf("day").toDate();

        const shifts = await Shifts.aggregate([
            {
                $match: {
                    guardId: uid,
                    date: { $gte: startFilter, $lte: endFilter }
                }
            },

            { $lookup: { from: "sites", localField: "siteId", foreignField: "id", as: "siteInfo" } },
            { $unwind: { path: "$siteInfo", preserveNullAndEmptyArrays: true } },
            { $project: { _id: 0, id: 1, date: 1, start: 1, end: 1, status: 1, liveStatus: 1, breakTime: 1, totalHours: 1, siteId: 1, siteName: "$siteInfo.name", siteAddress: "$siteInfo.address" } }
        ]);

        return res.status(200).json({ message: "Shifts fetched successfully.", shifts });

    } catch (error) {
        console.log(error);
        return res.status(500).json({ message: "Server Error", isError: true, error });
    }
})

router.patch("/update/:id", verifyToken, async (req, res) => {
    try {

        const { id } = req.params;
        const { uid } = req;
        const { guardId: newGuardId } = req.body;
        const updatedData = { ...req.body };

        if (!uid) { return res.status(401).json({ message: "Unauthorized access.", isError: true }); }

        const existingShift = await Shifts.findOne({ id });
        if (!existingShift) { return res.status(404).json({ message: "Shift not found.", isError: true }); }

        const oldGuardId = existingShift.guardId;

        const { start, end, siteId, guardId, breakTime } = updatedData

        const updatedShift = await Shifts.findOneAndUpdate(
            { id },
            { $set: { start: start, end: end, siteId: siteId, guardId: guardId, status: "pending", breakTime: breakTime } },
            { new: true }
        );

        const guardUser = await Users.findOne({ uid: updatedShift.guardId }, 'fullName uid');
        const siteData = await Sites.findOne({ id: updatedShift.siteId }, 'name city address');

        const shiftToSend = {
            ...updatedShift.toObject(),
            guardName: guardUser ? guardUser.fullName : "",
            siteName: siteData ? siteData.name : "",
            siteAddress: siteData ? siteData.address : "",
            siteCity: siteData ? JSON.parse(siteData.city || '{}').label : "",
        };

        const shiftMessage = `Your shift Update at ${shiftToSend.siteName}`;

        if (req.io) {
            if (newGuardId && newGuardId !== oldGuardId) {
                req.io.to(oldGuardId).emit('remove_shift_from_admin', { shift: shiftToSend, message: `Your shift has been removed from ${shiftToSend.siteName}` });
                req.io.to(newGuardId).emit('new_shift_added', { shift: shiftToSend, message: `You have been assigned a new shift at ${shiftToSend.siteName}` });
            }
            else if (updatedShift.guardId) {
                req.io.to(updatedShift.guardId).emit('shift_update_from_admin', { shift: shiftToSend, message: shiftMessage });
            }
        }

        res.status(200).json({ message: "Shift updated successfully", isError: false, shift: updatedShift });
    } catch (error) {
        console.error("Shift Update Error:", error);
        res.status(500).json({ message: "Something went wrong while updating the shift", isError: true, error: error.message });
    }
});

router.get("/live-operations", verifyToken, async (req, res) => {
    try {

        const { uid } = req

        const user = await Users.findOne({ uid })
        if (!user) return res.status(401).json({ message: "Unauthorized access.", isError: true })

        const { timeZone = "UTC" } = cleanObjectValues(req.query)

        const currentTimeUTC = dayjs().tz(timeZone).utc(true);
        const now = currentTimeUTC.toDate()
        const startOfDayUTC = currentTimeUTC.startOf('day').utc().toDate()
        const endOfDayUTC = currentTimeUTC.endOf('day').utc().toDate()

        await Shifts.updateMany(
            { liveStatus: 'awaiting', end: { $lt: now } },
            { $set: { liveStatus: 'missed', status: 'inactive' } }
        );

        const pipeline = [
            {
                $match: {
                    $or: [
                        { start: { $gte: startOfDayUTC, $lte: endOfDayUTC } },
                        { end: { $gte: startOfDayUTC, $lte: endOfDayUTC } }
                    ]
                }
            },
            { $lookup: { from: "sites", localField: "siteId", foreignField: "id", as: "siteDetails" } },
            { $unwind: "$siteDetails" },
            { $lookup: { from: "customers", localField: "siteDetails.customerId", foreignField: "id", as: "customerDetails" } },
            { $unwind: "$customerDetails" },
            { $match: { "customerDetails.companyId": user.companyId } },
            { $lookup: { from: "users", localField: "guardId", foreignField: "uid", as: "guardDetails" } },
            { $unwind: "$guardDetails" },
            { $project: { _id: 0, id: "$id", liveStatus: "$liveStatus", checkIn: "$checkIn", customer: "$customerDetails.name", site: "$siteDetails.name", name: "$guardDetails.fullName", status: "$status", startTime: "$start", endTime: "$end", locations: "$locations", checkOut: "$checkOut", guardId: "$guardId" } },
        ];

        const shifts = await Shifts.aggregate(pipeline);

        return res.status(200).json({ message: `Live shifts fetched for.`, shifts });

    } catch (error) {
        console.error("Error fetching live operations:", error);
        res.status(500).json({ message: "Server error during live operations fetch." });
    }
});

router.delete("/single/:id", verifyToken, async (req, res) => {
    try {
        const { id } = req.params;

        const shift = await Shifts.findOneAndDelete({ id });
        if (!shift) return res.status(404).json({ message: "Shift not found", isError: true });

        if (shift.guardId && req.io) { req.io.to(shift.guardId).emit('remove_shift_from_admin', { shift, message: `Shift remove`, }); }
        res.status(200).json({ message: "Shift deleted successfully", id });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Something went wrong", isError: true });
    }
});

const getShiftCounts = async (date, companyId) => {
    const counts = await Shifts.aggregate([{ $match: { end: { $gte: date }, companyId: companyId } }, { $group: { _id: '$status', count: { $sum: 1 } } }]);
    const result = { active: 0, pending: 0, request: 0 };
    counts.forEach(item => {
        if (item._id === 'active') result.active = item.count;
        if (item._id === 'pending') result.pending = item.count;
        if (item._id === 'request') result.request = item.count;
    });
    return result;
};

router.get("/all-with-status", verifyToken, async (req, res) => {
    try {

        const { uid } = req

        const user = await Users.findOne({ uid })
        if (!user) return res.status(401).json({ message: "Unauthorized access.", isError: true })

        const { status, siteId, guardName, email, date, perPage, pageNo, timeZone } = cleanObjectValues(req.query);

        const page = parseInt(pageNo) || 1;
        const limit = parseInt(perPage) || 10;
        const skip = (page - 1) * limit;

        let matchQuery = {};

        if (status) { matchQuery.status = status; }
        matchQuery.companyId = user.companyId

        const currentTimeUTC = dayjs().tz(timeZone).utc(true);
        const startOfDayUTC = currentTimeUTC.startOf("day").toDate();

        matchQuery.end = { $gte: startOfDayUTC };

        if (date) {
            const selectedDateUTC = dayjs(date);
            const nextDateUTC = selectedDateUTC.add(1, 'day');
            matchQuery.date = { $gte: selectedDateUTC.toDate(), $lt: nextDateUTC.toDate(), };
            delete matchQuery.end;
        }
        let pipeline = [
            { $match: matchQuery },
            { $lookup: { from: 'sites', localField: 'siteId', foreignField: 'id', as: 'siteInfo' } },
            { $unwind: { path: '$siteInfo', preserveNullAndEmptyArrays: true } },
            { $lookup: { from: 'users', localField: 'guardId', foreignField: 'uid', as: 'guardInfo' } },
            { $unwind: { path: '$guardInfo', preserveNullAndEmptyArrays: true } },
            {
                $match: {
                    $and: [
                        guardName ? { 'guardInfo.fullName': { $regex: guardName, $options: 'i' } } : {},
                        email ? { 'guardInfo.email': { $regex: email, $options: 'i' } } : {},
                        siteId ? { 'siteId': siteId } : {},
                    ]
                }
            },

            { $project: { id: '$id', start: '$start', end: '$end', date: '$date', status: '$status', reason: "$reason", liveStatus: '$liveStatus', totalHours: '$totalHours', siteId: '$siteId', siteName: '$siteInfo.name', guardId: '$guardId', guardName: '$guardInfo.fullName', guardEmail: '$guardInfo.email', } },
            { $sort: { start: 1 } },
            { $facet: { metadata: [{ $count: "totals" }], data: [{ $skip: skip }, { $limit: limit }] } }
        ];

        const [results] = await Shifts.aggregate(pipeline);

        const shifts = results.data;
        const totals = results.metadata[0]?.totals || 0;
        const counts = await getShiftCounts(startOfDayUTC, user.companyId);

        res.status(200).json({ shifts, counts, totals, isError: false });

    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Something went wrong while fetching shifts", isError: true, error });
    }
});

// router.patch("/updated-status/:id", verifyToken, async (req, res) => {
//     try {
//         const { id } = req.params;
//         const { uid } = req;
//         const { status } = req.body

//         if (!uid) return res.status(401).json({ message: "Unauthorized access.", isError: true });

//         const existingShift = await Shifts.findOne({ id });
//         if (!existingShift) return res.status(404).json({ message: "Shift not found.", isError: true });

//         const updatedShift = await Shifts.findOneAndUpdate(
//             { id },
//             { $set: { status: status } },
//             { new: true }
//         );

//         const guardId = updatedShift.guardId;

//         const guardUser = await Users.findOne({ uid: guardId }, 'fullName uid');
//         const siteData = await Sites.findOne({ id: updatedShift.siteId }, 'name city address');

//         const shiftToSend = {
//             ...updatedShift.toObject(),
//             guardName: guardUser ? guardUser.fullName : "",
//             siteName: siteData ? siteData.name : "",
//             guardEmail: guardUser ? guardUser.email : "",
//             siteAddress: siteData ? siteData.address : "",
//             siteCity: siteData ? JSON.parse(siteData.city || '{}').label : "",
//         };

//         if (guardId && req.io) { req.io.to(guardId).emit('request_approved', { shift: shiftToSend, message: `Your Request approved`, }); }

//         res.status(200).json({ message: "Shift updated successfully", isError: false, shift: updatedShift });
//     } catch (error) {
//         console.error(error);
//         res.status(500).json({ message: "Something went wrong while updating the shift", isError: true, error });
//     }
// });

router.patch("/request-approval/:id", verifyToken, async (req, res) => {
    try {
        const { id } = req.params;
        const { uid } = req;

        if (!uid) return res.status(401).json({ message: "Unauthorized access.", isError: true });

        const existingShift = await Shifts.findOne({ id });
        if (!existingShift) return res.status(404).json({ message: "Shift not found.", isError: true });

        const updatedShift = await Shifts.findOneAndUpdate(
            { id },
            { $set: { status: "active" } },
            { new: true }
        );
        const guardUser = await Users.findOne({ uid: updatedShift.guardId }, 'fullName email uid');
        const siteData = await Sites.findOne({ id: updatedShift.siteId }, 'name city address');

        const shiftToSend = {
            ...updatedShift.toObject(),
            guardName: guardUser ? guardUser.fullName : "",
            guardEmail: guardUser ? guardUser.email : "",
            siteName: siteData ? siteData.name : "",
            siteAddress: siteData ? siteData.address : "",
            siteCity: siteData ? JSON.parse(siteData.city || '{}').label : "",
        };

          req.io.emit('shift_approved', { shift: shiftToSend, message: `Shit Approved.` });

        res.status(200).json({ message: "Approval Request sent successfully", isError: false, shift: shiftToSend });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Something went wrong while sending approval request for shift", isError: true, error });
    }
});


router.patch("/send-request/:id", verifyToken, async (req, res) => {
    try {
        const { id } = req.params;
        const { uid } = req;
        const { reason } = req.body

        if (!uid) return res.status(401).json({ message: "Unauthorized access.", isError: true });

        const existingShift = await Shifts.findOne({ id });
        if (!existingShift) return res.status(404).json({ message: "Shift not found.", isError: true });

        const updatedShift = await Shifts.findOneAndUpdate(
            { id },
            { $set: { status: "request", reason: reason } },
            { new: true }
        );

        const guardUser = await Users.findOne({ uid: updatedShift.guardId }, 'fullName email uid');
        const siteData = await Sites.findOne({ id: updatedShift.siteId }, 'name city address');

        const shiftToSend = {
            ...updatedShift.toObject(),
            guardName: guardUser ? guardUser.fullName : "",
            guardEmail: guardUser ? guardUser.email : "",
            siteName: siteData ? siteData.name : "",
            siteAddress: siteData ? siteData.address : "",
            siteCity: siteData ? JSON.parse(siteData.city || '{}').label : "",
        };

        req.io.emit('new_request', { shift: shiftToSend, message: `New Request.` });

        res.status(200).json({ message: "Request sent successfully", isError: false, shift: updatedShift });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Something went wrong while sending request for shift", isError: true, error });
    }
});


router.patch("/check-in/:id", verifyToken, async (req, res) => {
    try {

        const { uid } = req;
        const { id: shiftId } = req.params;
        const { checkInTime, timeZone = "UTC" } = cleanObjectValues(req.query);

        const user = await Users.findOne({ uid })
        if (!user) return res.status(401).json({ message: "Unauthorized access.", isError: true })

        const alreadyActiveShift = await Shifts.findOne({ guardId: uid, status: "active", liveStatus: "checkIn" });
        if (alreadyActiveShift) { return res.status(400).json({ message: "You are already in a shift.", isError: true }); }

        const shift = await Shifts.findOne({ id: shiftId });
        if (!shift) { return res.status(404).json({ message: "Shift not found.", isError: true }); }

        const shiftStart = dayjs.utc(shift.start).tz(timeZone);
        const checkInDate = dayjs.tz(checkInTime, timeZone);

        let updatedTotalHours = shift.totalHours;
        let lateMinutes = 0;

        if (checkInDate.isAfter(shiftStart)) {
            lateMinutes = checkInDate.diff(shiftStart, "minute");
            const deductedHours = Math.ceil(lateMinutes / 30) * 0.5;
            updatedTotalHours = Math.max(shift.totalHours - deductedHours, 0);
        }

        const updatedShift = await Shifts.findOneAndUpdate(
            { id: shiftId },
            { $set: { status: "active", liveStatus: "checkIn", checkIn: checkInTime, totalHours: updatedTotalHours } },
            { new: true }
        );

        const site = await Sites.findOne({ id: updatedShift.siteId }).lean()
        const guardUser = await Users.findOne({ uid: updatedShift.guardId }, 'fullName email uid');
        const shiftFormat = { ...updatedShift.toObject(), site: site, guard: guardUser }

        if (!updatedShift) { return res.status(404).json({ message: "Shift not found.", isError: true }); }

        req.io.emit('shift_check_in', { shift: updatedShift, type: 'check_in', message: `Shift Chock In. by ${guardUser.fullName}` });
        if (updatedShift.guardId && req.io) { req.io.to(updatedShift.guardId).emit('shift_check_in', { shift: shiftFormat, message: `Shift clock-in`, }); }

        res.status(200).json({ message: "Check-in successful and shift updated.", isError: false, shift: shiftFormat });
    } catch (error) {
        console.error("Check-In Error:", error);
        res.status(500).json({ message: "Something went wrong during check-in", isError: true, error });
    }
});

router.patch("/check-out/:id", verifyToken, async (req, res) => {
    try {
        const { id: shiftId } = req.params;
        const { status = "inactive", liveStatus = "checkOut", checkOutTime, timeZone = "UTC" } = cleanObjectValues(req.query);

        const shift = await Shifts.findOne({ id: shiftId });
        if (!shift) return res.status(404).json({ message: "Shift not found.", isError: true });

        // 🕒 Timezone-aware
        const shiftEnd = dayjs.utc(shift.end).tz(timeZone);
        const checkOutDate = dayjs.tz(checkOutTime, timeZone);

        let updatedTotalHours = shift.totalHours;
        let earlyMinutes = 0;

        if (checkOutDate.isBefore(shiftEnd)) {
            // Early check-out deduction
            earlyMinutes = shiftEnd.diff(checkOutDate, "minute");
            const deductedHours = Math.ceil(earlyMinutes / 30) * 0.5;
            updatedTotalHours = Math.max(shift.totalHours - deductedHours, 0);
        }

        const guard = await Users.findOne({ uid: shift.guardId })

        const totalPay = updatedTotalHours * guard.perHour

        const updatedShift = await Shifts.findOneAndUpdate(
            { id: shiftId },
            { $set: { status: status, liveStatus: liveStatus, checkOut: checkOutTime, totalHours: updatedTotalHours, totalPayments: totalPay } },
            { new: true }
        );

        const site = await Sites.findOne({ id: updatedShift.siteId }).lean()
        const guardUser = await Users.findOne({ uid: updatedShift.guardId }, 'fullName email perHours uid');
        const shiftFormat = { ...updatedShift.toObject(), site, guard: guardUser }

        if (!updatedShift) { return res.status(404).json({ message: "Shift not found.", isError: true }); }

        req.io.emit('shift_check_out', { shift: updatedShift, type: 'check_Out', message: `Shift Check Out.` });
        if (updatedShift.guardId && req.io) { req.io.to(updatedShift.guardId).emit('shift_check_out', { shift: shiftFormat, message: `Shift clock-Out`, }); }

        res.status(200).json({ message: "Check-Out successful and shift updated.", isError: false, shift: shiftFormat });

    } catch (error) {
        console.error("Check-In Error:", error);
        res.status(500).json({ message: "Something went wrong during check-in", isError: true, error });
    }
});

router.patch("/drop-pin/:id", verifyToken, async (req, res) => {

    const { id } = req.params;
    const { latitude, longitude, time } = req.body;

    if (!latitude || !longitude || !time) { return res.status(400).json({ success: false, message: "Latitude and Longitude or Time are required." }); }

    try {
        const updatedShift = await Shifts.findOneAndUpdate(
            { id },
            {
                $push: {
                    locations: {
                        longitude: longitude,
                        latitude: latitude,
                        time: time,
                    }
                }
            },
            { new: true, runValidators: true }
        );

        if (!updatedShift) { return res.status(404).json({ success: false, message: "Shift not found with this ID." }); }

        req.io.emit('shift_drop_pin', { shift: updatedShift, type: 'drop_pin', message: `New Drop Pin.` });
        return res.status(200).json({ success: true, message: "Location successfully updated.", shift: updatedShift });

    } catch (error) {
        console.error("Error updating location:", error);
        return res.status(500).json({ success: false, message: "Server error occurred while updating location.", error });
    }
});

// // Function to upload a file to Cloudinary
const uploadToCloudinary = (file) => {
    return new Promise((resolve, reject) => {
        const resourceType = file.mimetype.startsWith("video/") ? "video" : "image";

        const uploadStream = cloudinary.uploader.upload_stream(
            { folder: "incidents", resource_type: resourceType },  // Set resource type dynamically
            (error, result) => {
                if (error) return reject(error);
                resolve({
                    name: file.originalname,
                    url: result.secure_url,
                    type: file.mimetype,
                    publicId: result.public_id
                });
            }
        );
        uploadStream.end(file.buffer);
    });
};

// Route to upload attachments for a donation
router.post("/upload-attachments/:id", upload.array("files"), async (req, res) => {
    try {
        const { id } = req.params;
        if (!req.files?.length) { return res.status(400).json({ message: "No files uploaded", isError: true }); }

        const uploadedFiles = await Promise.all(req.files.map(uploadToCloudinary));

        const updatedShift = await Shifts.findOneAndUpdate({ id }, { $push: { attachments: { $each: uploadedFiles } } }, { new: true });

        const site = await Sites.findOne({ id: updatedShift.siteId }).lean()
        const guardUser = await Users.findOne({ uid: updatedShift.guardId }, 'fullName email uid');
        const customer = await Customers.findOne({ id: site.customerId })
        const shiftFormat = { ...updatedShift.toObject(), site, guard: guardUser, customer }

        if (!updatedShift) { return res.status(404).json({ message: "Shift not found", isError: true }); }

        req.io.emit('shift_incident', { shift: shiftFormat, type: 'incident', message: `Incident at ${shiftFormat.site.name}.` });
        res.status(200).json({ message: "Incidents uploaded successfully", shift: shiftFormat, isError: false });

    } catch (error) {
        console.error("Error uploading attachments:", error);
        res.status(500).json({ message: "Something went wrong", isError: true, error: error.message });
    }
});

router.get("/incidents", verifyToken, async (req, res) => {
    try {

        const { uid } = req

        const user = await Users.findOne({ uid })
        if (!user) return res.status(401).json({ message: "Unauthorized access.", isError: true })


        const { startDate, endDate, timeZone } = cleanObjectValues(req.query);

        const currentTimeUTC = dayjs().tz(timeZone).utc(true);

        let start = currentTimeUTC.startOf("day").toDate();
        let end = currentTimeUTC.endOf("day").toDate();

        if (startDate && endDate) {
            start = dayjs(startDate).startOf("day").toDate();
            end = dayjs(endDate).endOf("day").toDate();
        }
        const data = await Shifts.aggregate([
            {
                $match: {
                    companyId: user.companyId,
                    attachments: { $exists: true, $not: { $size: 0 } },
                    $or: [
                        { start: { $gte: start, $lte: end } },
                        { end: { $gte: start, $lte: end } }
                    ]
                }
            },
            { $lookup: { from: "sites", localField: "siteId", foreignField: "id", as: "site" } },
            { $unwind: "$site" },
            { $lookup: { from: "customers", localField: "customerId", foreignField: "id", as: "customer" } },
            { $unwind: "$customer" },
            { $lookup: { from: "users", localField: "guardId", foreignField: "uid", as: "guard" } },
            { $unwind: "$guard" },
            { $project: { customer: "$customer.name", name: "$site.name", fullName: "$guard.fullName", address: "$site.address", date: "$date", attachments: 1 } }
        ]);

        res.status(200).json({ incidents: data, total: data.length });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Something went wrong" });
    }
});



module.exports = router