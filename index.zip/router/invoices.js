const express = require("express");
const router = express.Router();
const Invoices = require("../models/invoices");
const Transactions = require("../models/Transactions");
const Companies = require("../models/companies");
const Users = require("../models/auth");
const Customers = require("../models/customers");
const Sites = require("../models/sites");
const Taxes = require("../models/taxes");
const { verifyToken } = require("../middlewares/auth");
const { getRandomId, cleanObjectValues } = require("../config/global");
const sendMail = require("../utils/sendMail");
const dayjs = require("dayjs");
const utc = require('dayjs/plugin/utc');
const timezone = require('dayjs/plugin/timezone');

dayjs.extend(utc);
dayjs.extend(timezone);

const generateInvoicePDF = require("../utils/invoicePdfGenerator");

const getInvoiceEmailBody = (company, invoice) => {
    return `
        <div style="font-family: Arial, sans-serif; color: #333; line-height: 1.6;">
            <div style="border-bottom: 2px solid #eee; padding-bottom: 20px; margin-bottom: 20px;">
                <h2 style="color: #2c3e50; margin: 0;">New Incoming Invoice</h2>
                <p style="margin: 5px 0 0; color: #7f8c8d;">Security Matrix AI</p>
            </div>

            <p>Dear ${company.name},</p>
            <p>Please find attached your invoice for <strong>${dayjs(invoice.billingPeriod).format("MMMM YYYY")}</strong>.</p>
            
            <div style="background-color: #f9f9f9; border: 1px solid #e0e0e0; border-radius: 5px; padding: 20px; margin: 20px 0;">
                <table style="width: 100%; border-collapse: collapse;">
                    <tr>
                        <td style="padding: 8px 0; color: #7f8c8d;">Invoice Number:</td>
                        <td style="padding: 8px 0; font-weight: bold; text-align: right;">${invoice.invoiceNo}</td>
                    </tr>
                    <tr>
                        <td style="padding: 8px 0; color: #7f8c8d;">Invoice Date:</td>
                        <td style="padding: 8px 0; font-weight: bold; text-align: right;">${new Date(invoice.issueDate).toLocaleDateString()}</td>
                    </tr>
                    <tr>
                        <td style="padding: 8px 0; color: #7f8c8d;">Due Date:</td>
                        <td style="padding: 8px 0; font-weight: bold; text-align: right;">${new Date(invoice.dueDate).toLocaleDateString()}</td>
                    </tr>
                    <tr>
                        <td style="border-top: 1px solid #ddd; padding: 12px 0 0; font-weight: bold;">Total Amount:</td>
                        <td style="border-top: 1px solid #ddd; padding: 12px 0 0; font-weight: bold; text-align: right; color: #2c3e50;">${Number(invoice.totalAmount).toFixed(2)}</td>
                    </tr>
                    <tr>
                        <td style="padding: 8px 0; font-weight: bold; color: #d32f2f;">Balance Due:</td>
                        <td style="padding: 8px 0; font-weight: bold; text-align: right; color: #d32f2f;">${Number(invoice.balanceDue).toFixed(2)}</td>
                    </tr>
                </table>
            </div>

            <p>If you have any questions regarding this invoice, please do not hesitate to contact us at <a href="mailto:contact@securitymatrixai.com" style="color: #3498db; text-decoration: none;">contact@securitymatrixai.com</a>.</p>
            
            <br/>
            <p style="font-size: 0.9em; color: #7f8c8d;">
                Thank you for your business,<br/>
                <strong>Security Matrix AI</strong><br/>
                Suite 12 Fountain House, Fountain Lane<br/>
                Oldbury, B69 3BH, United Kingdom
            </p>
        </div>
    `;
};

// Create a new invoice manually
router.post("/generate", verifyToken, async (req, res) => {
    try {
        const { uid } = req;
        const { companyId, mode, billingPeriod, dueDate, tax: manualTax, billingBasis } = req.body;

        if (!uid) return res.status(401).json({ message: "Unauthorized", isError: true });
        if (!companyId) return res.status(400).json({ message: "Company ID is required", isError: true });

        const company = await Companies.findOne({ id: companyId });
        if (!company) return res.status(404).json({ message: "Company not found", isError: true });

        const basis = billingBasis || company.billingBasis || 'customers';

        const getQuantity = async () => {
            if (basis === 'customers') return await Customers.countDocuments({ status: "active", companyId });
            if (basis === 'sites') return await Sites.countDocuments({ status: "active", companyId });
            if (basis === 'guards') return await Users.countDocuments({ status: "active", companyId, roles: { $in: ["guard"] } });
            if (basis === 'yearly') return 1;
            return 1;
        };

        let quantity = await getQuantity();

        let rate = company.rate || 0;
        rate = Number(rate.toFixed(2));

        // Free Trial Calculation (Legacy Logic - keeping if needed, but Manual Discount overrides)
        // If manual discount is provided, we use that. Otherwise we check for free trial overlap.
        const { taxId, discountType = 'amount', discountValue = 0 } = req.body;

        let discount = 0;
        let finalDiscountValue = Number(discountValue);

        // Calculate Subtotal first
        const subtotal = Number((quantity * rate).toFixed(2));

        // Calculate Discount
        if (finalDiscountValue > 0) {
            if (discountType === 'percentage') {
                discount = Number(((subtotal * finalDiscountValue) / 100).toFixed(2));
            } else {
                discount = Number(finalDiscountValue.toFixed(2));
            }
        } else {
            // Fallback to legacy trial logic if no manual discount
            if (company.trialStartDate && company.trialEndDate && billingPeriod) {
                // Parse billing period string (e.g. "January 2024")
                const periodDate = dayjs(billingPeriod, "MMMM YYYY");
                if (periodDate.isValid()) {
                    const startOfMonth = periodDate.startOf('month');
                    const endOfMonth = periodDate.endOf('month');

                    const trialStart = dayjs(company.trialStartDate);
                    const trialEnd = dayjs(company.trialEndDate);

                    // Calculate Overlap
                    const overlapStart = trialStart.isAfter(startOfMonth) ? trialStart : startOfMonth;
                    const overlapEnd = trialEnd.isBefore(endOfMonth) ? trialEnd : endOfMonth;

                    if (overlapStart.isBefore(overlapEnd) || overlapStart.isSame(overlapEnd, 'day')) {
                        const overlapDays = overlapEnd.diff(overlapStart, 'day') + 1;
                        const daysInMonth = endOfMonth.date();
                        const totalCost = rate * quantity;
                        discount = Number(((totalCost / daysInMonth) * overlapDays).toFixed(2));
                        // If legacy trial logic kicks in, treat it as amount discount
                        finalDiscountValue = discount;
                    }
                }
            }
        }

        const previousInvoices = await Invoices.find({
            companyId: company.id,
            status: { $in: ['draft', 'sent', 'partiallyPaid'] },
            id: { $ne: req.body.invoiceId } // Just in case, though usually manual gen doesn't send ID
        });

        const previousBalance = previousInvoices.reduce((sum, inv) => sum + (inv.balanceDue || 0), 0);
        const previousInvoiceIds = previousInvoices.map(inv => inv.id);

        if (previousInvoiceIds.length > 0) {
            await Invoices.updateMany(
                { id: { $in: previousInvoiceIds } },
                { $set: { status: 'rolledOver', balanceDue: 0 } }
            );
        }

        const netAfterDiscount = Number(Math.max(0, subtotal - discount).toFixed(2));

        // Tax Calculation
        let taxAmount = 0;
        let taxRate = 0;
        let taxName = 'No Tax';

        if (taxId) {
            const taxDoc = await Taxes.findOne({ id: taxId });
            if (taxDoc) {
                taxRate = taxDoc.rate;
                taxName = taxDoc.name;
                taxAmount = Number(((netAfterDiscount * taxRate) / 100).toFixed(2));
            }
        } else if (req.body.tax) {
            // Fallback for random manual tax amount passed directly (legacy support)
            taxAmount = Number(req.body.tax);
            taxName = 'Manual Tax';
            // Approximate rate for record
            if (netAfterDiscount > 0) taxRate = Number(((taxAmount / netAfterDiscount) * 100).toFixed(2));
        }

        const total = Number((netAfterDiscount + taxAmount + previousBalance).toFixed(2));

        const invoice = {
            id: getRandomId(), companyId: company.id, billingPeriod, billingBasis,
            dueDate,
            issueDate: new Date(),
            rate, quantity,
            tax: taxAmount,
            taxId: taxId || null,
            taxName,
            taxRate,
            subtotal,
            discount,
            discountType,
            discountValue: finalDiscountValue,
            previousBalance,
            previousInvoiceIds,
            totalAmount: total,
            balanceDue: total,
            createdBy: uid,
            status: mode === 'send' ? 'sent' : 'draft',
        };

        const invoiceDoc = new Invoices(invoice);

        await invoiceDoc.save();

        if (mode === 'send') {
            try {
                const pdfBuffer = await generateInvoicePDF(invoiceDoc, company);
                const emailBody = getInvoiceEmailBody(company, invoiceDoc);

                await sendMail(company.email, `Invoice ${invoiceDoc.invoiceNo} from Security Matrix AI`, emailBody, [
                    { filename: `Invoice-${invoiceDoc.invoiceNo}.pdf`, content: pdfBuffer, contentType: 'application/pdf' }
                ]);
            } catch (mailError) {
                console.error("Failed to send email during generation:", mailError);
                return res.status(200).json({ message: "Invoice generated but failed to send email", isError: false, invoices: [invoiceDoc] });
            }
        }

        res.status(201).json({
            message: `Invoice ${mode === 'send' ? 'generated & sent' : 'generated'} successfully`,
            isError: false,
            invoices: [invoice] // Keep array format for frontend compatibility if needed, or just change frontend
        });

    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Error generating invoice", isError: true, error: error.message });
    }
});
// Get all invoices with filters
router.get("/all", verifyToken, async (req, res) => {
    try {
        const { uid } = req;
        if (!uid) return res.status(401).json({ message: "Unauthorized access.", isError: true });

        let { pageNo = 1, perPage = 10, status, search, companyId, startDate, endDate } = cleanObjectValues(req.query);
        const timeZone = req.headers["x-timezone"] || req.query.timeZone || "UTC";

        pageNo = Number(pageNo);
        perPage = Number(perPage);
        const skip = (pageNo - 1) * perPage;

        const match = {};

        if (status) match.status = status;
        if (companyId) match.companyId = companyId;

        // Date Filtering
        if (startDate || endDate) {
            match.issueDate = {};
            if (startDate) match.issueDate.$gte = dayjs(startDate).tz(timeZone).startOf('day').utc(true).toDate();
            if (endDate) match.issueDate.$lte = dayjs(endDate).tz(timeZone).endOf('day').utc(true).toDate();
        }

        const pipeline = [
            { $match: match },
            { $lookup: { from: "companies", localField: "companyId", foreignField: "id", as: "company" } },
            { $unwind: { path: "$company", preserveNullAndEmptyArrays: true } },
        ];

        // Search Filter (Applied after lookup to search company name)
        if (search) {
            pipeline.push({
                $match: {
                    $or: [
                        { invoiceNo: { $regex: search, $options: "i" } },
                        { "company.name": { $regex: search, $options: "i" } },
                        { "company.registrationNo": { $regex: search, $options: "i" } }
                    ]
                }
            });
        }

        pipeline.push(
            { $sort: { createdAt: -1 } },
            {
                $facet: {
                    data: [{ $skip: skip }, { $limit: perPage }],
                    total: [{ $count: "count" }]
                }
            }
        );

        const result = await Invoices.aggregate(pipeline);

        const invoices = result[0].data;
        const total = result[0].total[0]?.count || 0;

        res.status(200).json({ message: "Invoices fetched successfully", isError: false, invoices, total });

    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Something went wrong while fetching invoices", isError: true, error });
    }
});

// Get a single invoice
router.get("/single/:id", verifyToken, async (req, res) => {
    try {
        const { id } = req.params;
        const invoice = await Invoices.findOne({ id }).populate("companyId", "name email").lean();

        if (!invoice) return res.status(404).json({ message: "Invoice not found", isError: true });

        res.status(200).json({ invoice });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Internal Server Error", isError: true, error });
    }
});

// Update an invoice
router.patch("/update/:id", verifyToken, async (req, res) => {
    try {
        const { id } = req.params;
        const updates = req.body;

        const invoice = await Invoices.findOneAndUpdate({ id }, updates, { new: true });

        if (!invoice) return res.status(404).json({ message: "Invoice not found", isError: true });

        res.status(200).json({ message: "Invoice updated successfully", isError: false, invoice });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Internal Server Error", isError: true, error });
    }
});

// Pay an invoice
router.post("/pay/:id", verifyToken, async (req, res) => {
    try {
        const { uid } = req;
        const { id } = req.params; // Invoice ID

        let { amount, method, remarks, date } = req.body;
        amount = Number(amount);

        if (!uid) return res.status(401).json({ message: "Unauthorized access.", isError: true });
        if (!amount || isNaN(amount) || amount <= 0) return res.status(400).json({ message: "Invalid amount", isError: true });

        const invoice = await Invoices.findOne({ id });
        if (!invoice) return res.status(404).json({ message: "Invoice not found", isError: true });

        if (invoice.balanceDue < amount) {
            return res.status(400).json({ message: "Amount exceeds balance due", isError: true });
        }

        const transactionId = getRandomId();

        // Create Transaction
        const transaction = new Transactions({
            id: transactionId, companyId: invoice.companyId, invoiceId: invoice.id, amount, method, status: "successfully",
            billingMonth: invoice.billingPeriod, remarks,
            transactionDate: date || new Date(), approvedBy: uid, createdBy: uid
        });

        await transaction.save();

        // Update Invoice Payment Details
        invoice.amountPaid = Number(((invoice.amountPaid || 0) + amount).toFixed(2));
        invoice.balanceDue = Number((invoice.totalAmount - invoice.amountPaid).toFixed(2));

        if (invoice.balanceDue <= 0) {
            invoice.status = 'paid';
            invoice.balanceDue = 0; // Prevent negative
        } else if (invoice.balanceDue < invoice.totalAmount) {
            invoice.status = 'partiallyPaid';
        }

        if (!invoice.transactionsIds) invoice.transactionsIds = [];
        invoice.transactionsIds.push(transactionId);

        await invoice.save();

        res.status(200).json({ message: "Payment recorded successfully", isError: false, invoice, transaction });

    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Internal Server Error", isError: true, error: error.message });
    }
});

// Send Invoices via Email
router.post("/send", verifyToken, async (req, res) => {
    try {
        const { uid } = req;
        const { invoiceIds } = req.body; // Array of IDs

        if (!uid) return res.status(401).json({ message: "Unauthorized access.", isError: true });
        if (!invoiceIds || !Array.isArray(invoiceIds) || invoiceIds.length === 0) {
            return res.status(400).json({ message: "No invoices selected", isError: true });
        }

        const invoices = await Invoices.find({ id: { $in: invoiceIds } });

        // Manual populate because companyId is a String(custom ID), not ObjectId
        const companyIds = [...new Set(invoices.map(inv => inv.companyId))];
        const companies = await Companies.find({ id: { $in: companyIds } });
        const companyMap = companies.reduce((acc, comp) => {
            acc[comp.id] = comp;
            return acc;
        }, {});

        let sentCount = 0;

        for (const invoice of invoices) {
            const company = companyMap[invoice.companyId];
            if (company && company.email) {
                // Generate PDF
                // Generate PDF
                const pdfBuffer = await generateInvoicePDF(invoice, company);
                const emailBody = getInvoiceEmailBody(company, invoice);

                // Attachments array for nodemailer
                const attachments = [
                    {
                        filename: `Invoice-${invoice.invoiceNo}.pdf`,
                        content: pdfBuffer,
                        contentType: 'application/pdf'
                    }
                ];

                await sendMail(company.email, `Invoice ${invoice.invoiceNo} from Security Matrix AI`, emailBody, attachments);

                if (invoice.status === 'draft') {
                    invoice.status = 'sent';
                    await invoice.save();
                }
                sentCount++;
            }
        }

        res.status(200).json({ message: `Successfully sent ${sentCount} invoices.`, sentCount });

    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Failed to send emails", isError: true, error: error.message });
    }
});

// Delete an invoice
router.delete("/remove/:id", verifyToken, async (req, res) => {
    try {
        const { id } = req.params;
        const deleted = await Invoices.findOneAndDelete({ id });

        if (!deleted) return res.status(404).json({ message: "Invoice not found", isError: true });

        res.status(200).json({ message: "Invoice deleted successfully", isError: false });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Internal Server Error", isError: true, error });
    }
});



// Invoice Tracker Stats
router.get("/tracker", verifyToken, async (req, res) => {
    try {
        let { startDate, endDate } = cleanObjectValues(req.query);
        const timeZone = req.headers["x-timezone"] || req.query.timeZone || "UTC";

        const start = startDate ? dayjs(startDate).tz(timeZone).startOf('month').utc(true).toDate() : dayjs().tz(timeZone).startOf('month').utc(true).toDate();
        const end = endDate ? dayjs(endDate).tz(timeZone).endOf('month').utc(true).toDate() : dayjs().tz(timeZone).endOf('month').utc(true).toDate();
        // 1. Invoices stats in period
        const invoiceStats = await Invoices.aggregate([
            { $match: { issueDate: { $gte: start, $lte: end } } },
            {
                $group: {
                    _id: null,
                    count: { $sum: 1 },
                    totalAmount: { $sum: "$totalAmount" },
                    totalPending: { $sum: "$balanceDue" }
                }
            }
        ]);

        // 2. Transactions stats in period
        const transactionStats = await Transactions.aggregate([
            { $match: { transactionDate: { $gte: start, $lte: end }, status: "successfully" } },
            {
                $group: {
                    _id: null,
                    count: { $sum: 1 },
                    totalReceived: { $sum: "$amount" }
                }
            }
        ]);

        // 3. Billable companies (for pending generation)
        const eligibleCompanies = await Companies.countDocuments({
            status: { $ne: 'inactive' },
            $or: [
                { trialEndsAt: { $lt: new Date() } },
                { trialEndsAt: null }
            ]
        });

        const tracker = {
            totalInvoices: invoiceStats[0]?.count || 0,
            invoicesTotalAmount: invoiceStats[0]?.totalAmount || 0,
            totalTransactions: transactionStats[0]?.count || 0,
            amountReceived: transactionStats[0]?.totalReceived || 0,
            amountPending: invoiceStats[0]?.totalPending || 0,
            eligibleCompanies // This helps show how many companies *should* have invoices
        };

        res.status(200).json({ message: "Tracker data fetched", isError: false, tracker });

    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Error fetching tracker data", isError: true, error });
    }
});


module.exports = router;
